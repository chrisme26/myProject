﻿SELECT * FROM tblPO
SELECT * FROM tblDealer


