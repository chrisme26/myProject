﻿using PurchaseOrderSystem.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseOrderSystem.Controllers
{
    public class DealerController : Controller
    {
        //
        // GET: /Dealer/
        public ActionResult Dealer()
        {
            if (Session["User"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            IList<Lookups> items = new List<Lookups>
            {
                new Lookups{ Code = "Metro Manila", Desc = "Metro Manila" },   
                new Lookups{ Code = "Pampanga", Desc = "Pampanga" },
                new Lookups{ Code = "Batangas", Desc = "Batangas" },
                new Lookups{ Code = "Cavite", Desc = "Cavite" },
            };

            ViewBag.Province = new SelectList(items, "Code", "Desc");
            
            return View();
        }

        [HttpPost]
        public ActionResult Dealer(string Province, HttpPostedFileBase file)
        {            
            if (file != null && file.ContentLength > 0)
            {            
                var fileName = Path.GetFileName(file.FileName);            
                var path = Path.Combine(Server.MapPath("~/App_Data/XML"), fileName);
                file.SaveAs(path);
                
                DataSet ds = new DataSet();
                ds.ReadXml(Server.MapPath("~/App_Data/XML/" + fileName));

                DataTable dt = ds.Tables[0];
                int cnt = ds.Tables[0].Rows.Count;
                for (int i = 0; i <= cnt - 1; i++)
                {                    
                    using (var dealer = new PODBContext())
                    {
                        Dealer d = new Dealer();
                        d.Province = Province;
                        d.Name = dt.Rows[i]["Name"].ToString();
                        d.City = dt.Rows[i]["City"].ToString();
                        d.Location = dt.Rows[i]["Location"].ToString();
                        d.PhoneNo = dt.Rows[i]["PhoneNumber"].ToString();

                        dealer.Set<Dealer>().Add(d);
                        dealer.SaveChanges();
                    }
                }
                                
                System.IO.File.Delete(Path.Combine(Server.MapPath("~/App_Data/XML"), fileName));
                GC.Collect();
                Session["upload"] = "Data has been successfully uploaded.";
            }

            return RedirectToAction("Dealer", "Dealer");
        }
    }
}