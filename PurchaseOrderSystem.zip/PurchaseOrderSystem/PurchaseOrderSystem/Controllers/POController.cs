﻿using Newtonsoft.Json;
using PurchaseOrderSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseOrderSystem.Controllers
{
    public class POController : Controller
    {
        //
        // GET: /PO/
        public ActionResult PO()
        {
            if (Session["User"] == null)
            {
                return RedirectToAction("Login", "Login");
            }

            IList<Lookups> province = new List<Lookups>
            {
                new Lookups{ Code = "Metro Manila", Desc = "Metro Manila" },  
            };

            //ViewBag.Province = new SelectList(province, "Code", "Desc", "1");
            ViewBag.Province = new SelectList(province, "Code", "Desc");

            IList<Lookups> city = new List<Lookups>
            {
                new Lookups{ Code = "Manila City", Desc = "Manila City" },   
                new Lookups{ Code = "Quezon City", Desc = "Quezon City" },
                new Lookups{ Code = "Makati City", Desc = "Makati City" },                
            };

            ViewBag.City = new SelectList(city, "Code", "Desc");

            IList<Lookups> iphone = new List<Lookups>
            {
                new Lookups{ Code = "iPhone SE", Desc = "iPhone SE" },   
                new Lookups{ Code = "iPhone 6s", Desc = "iPhone 6s" },
                new Lookups{ Code = "iPhone 7", Desc = "iPhone 7" },                
            };

            ViewBag.IPhone = new SelectList(iphone, "Code", "Desc");

            List<Dealer> lst = new List<Dealer>();
            using (var db = new PODBContext())
            {
                lst = db.Database.SqlQuery<Dealer>("[dbo].[selectDealer]").ToList();
            }
                        
            return View(lst);
        }

        public JsonResult NewPO(string lst)
        {
            List<string> data = JsonConvert.DeserializeObject<List<string>>(lst);

            using (var po = new PODBContext())
            {
                PO p = new PO();
                p.Province = data[0];
                p.City = data[1];
                p.IPhoneModel = data[2];
                p.DealerDetails = data[3];
                p.Quantity = (data[4] == "") ? 0 : int.Parse(data[4]);
                p.CustomerName = data[5];
                p.ContactNumber = data[6];
                p.BookingDate = DateTime.Now.ToShortDateString();
                p.ShipmentAddress = data[7];

                po.Set<PO>().Add(p);
                po.SaveChanges();                
            }

            //GC.Collect();

            return Json("Data has been successfully saved.", JsonRequestBehavior.AllowGet);
        }
	}
}