﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PurchaseOrderSystem.Models;
using System.Data.SqlClient;

namespace PurchaseOrderSystem.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        public ActionResult Login()
        {            
            return View();
        }

        [HttpPost]
        public ActionResult Login(string User, string Pass)
        {
            Login usr = new Login();            
            using (var db = new PODBContext())
            {
                SqlParameter paramUser = new SqlParameter("@User", User);
                SqlParameter paramPass = new SqlParameter("@Pass", Pass);
                usr = db.Database.SqlQuery<Login>("[dbo].[selectLogin] @User, @Pass", paramUser, paramPass).FirstOrDefault();
                if (usr == null)
                {
                    Session["Invalid"] = "Invalid login. Please try again.";
                    return RedirectToAction("Login", "Login");
                }
                if (usr.Username.Equals(User) && usr.Password.Equals(Pass))
                {
                    Session["User"] = new Login() { Username = User, Name = usr.Name };
                    return RedirectToAction("Index", "Home");
                }
            }

            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }
	}
}