﻿using PurchaseOrderSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseOrderSystem.Controllers
{
    public class SalesReportController : Controller
    {
        //
        // GET: /SalesReport/        
        public ActionResult Report()
        {
            if (Session["User"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
                        
            List<PO> lst = new List<PO>();
            using (var db = new PODBContext())
            {
                SqlParameter paramStart = new SqlParameter("@Start", DBNull.Value);
                SqlParameter paramEnd = new SqlParameter("@End", DBNull.Value);
                lst = db.Database.SqlQuery<PO>("[dbo].[selectPO] @Start, @End", paramStart, paramEnd).ToList();
            }

            return View(lst);
        }

        [HttpPost]
        public ActionResult Report(string startdate, string enddate)
        {
            if (Session["User"] == null)
            {
                return RedirectToAction("Login", "Login");
            }

            List<PO> lst = new List<PO>();
            using (var db = new PODBContext())
            {
                SqlParameter paramStart = new SqlParameter("@Start", startdate);
                SqlParameter paramEnd = new SqlParameter("@End", enddate);
                lst = db.Database.SqlQuery<PO>("[dbo].[selectPO] @Start, @End", paramStart, paramEnd).ToList();
            }

            return View(lst);
        }
	}
}