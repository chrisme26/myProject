namespace PurchaseOrderSystem.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblPO")]
    public partial class PO
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Province { get; set; }

        [StringLength(50)]
        public string City { get; set; }

        [StringLength(20)]
        public string IPhoneModel { get; set; }

        public string DealerDetails { get; set; }

        public int? Quantity { get; set; }

        [StringLength(50)]
        public string CustomerName { get; set; }

        [StringLength(15)]
        public string ContactNumber { get; set; }

        [StringLength(30)]
        public string BookingDate { get; set; }

        [StringLength(150)]
        public string ShipmentAddress { get; set; }
    }
}
