namespace PurchaseOrderSystem.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblDealer")]
    public partial class Dealer
    {
        public int Id { get; set; }

        [StringLength(50)]
        public string Province { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(50)]
        public string City { get; set; }

        [StringLength(50)]
        public string Location { get; set; }

        [StringLength(20)]
        public string PhoneNo { get; set; }
    }
}
