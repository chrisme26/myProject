namespace PurchaseOrderSystem.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class PODBContext : DbContext
    {
        public PODBContext()
            : base("name=PODBContext")
        {
        }

        public virtual DbSet<Dealer> tblDealers { get; set; }
        public virtual DbSet<Login> tblLogins { get; set; }
        public virtual DbSet<PO> tblPOes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Login>()
                .Property(e => e.Name)
                .IsUnicode(false);
        }
    }
}
